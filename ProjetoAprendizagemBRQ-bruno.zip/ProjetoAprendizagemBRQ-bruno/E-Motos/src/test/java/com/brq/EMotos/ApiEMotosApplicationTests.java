package com.brq.EMotos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiEMotosApplicationTests {

	@Test
	void contextLoads() {
	}

}

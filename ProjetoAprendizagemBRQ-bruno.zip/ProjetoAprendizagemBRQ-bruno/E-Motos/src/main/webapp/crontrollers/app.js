var app = angular.module('app', ['ngRoute']);

/*
app.config(function($routeProvider, $locationProvider){
    $routeProvider.when('/login', {
        templateUrl: './view/register.jsp',
        controller: 'loginController'
    }).when('/register', {
        templateUrl: './view/register.jsp',
        controller: 'registerController'
    }).otherwise({ rediretTo: '/' })

    $locationProvider.html5Mode(true)
})
*/




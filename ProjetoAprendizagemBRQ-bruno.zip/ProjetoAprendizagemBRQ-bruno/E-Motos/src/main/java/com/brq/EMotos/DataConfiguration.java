package com.brq.EMotos;

import org.springframework.context.annotation.Configuration;

@Configuration
public class DataConfiguration {

}


angular.module('app', ['ngRoute', 'ngAnimate']);

// $rootScope = scopo pai, onde todos tem acesso